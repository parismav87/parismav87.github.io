$(document).ready(function(){

	$(".info-link").on("mouseenter", function(evt){
		if($(window).width() > 1080){
			var file = $(this).data("img");
			$(".main-content-leftbar-image").attr("src", file);
			$(".fun-fact").html($(this).data("funfact"));
		}
	})

	$(".info-link").on("mouseout", function(evt){
		if($(window).width() > 1080){
			var file = $(this).data("img");
			$(".main-content-leftbar-image").attr("src", "paris_bw.jpg");
			$(".fun-fact").html("");
		}
	})

	$(".top-menu-item").on("click", function(evt){
		evt.preventDefault();
		if($(window).width() <= 1080){ //"mobile"
			var el = $(this).find(".top-menu-item-text").data("scrollto");
			var elementTop = $(el).position().top;
			var currentScroll = $(".main-content").scrollTop();
			var leftBarHeight = $(".main-content-leftbar").height();
			if(elementTop != currentScroll || elementTop-leftBarHeight<0){
				$(".main-content").animate({
					scrollTop: elementTop + leftBarHeight 
				}, 500)			
			}
		} else { //desktop?
			var el = $(this).find(".top-menu-item-text").data("scrollto");
			var currentScroll = $(".content").scrollTop();
			if($(el).position().top != $(".content").scrollTop() || $(el).position().top<0){
				$('.content').animate({
			        scrollTop: $(el).position().top + $(".content").scrollTop()
			    }, 500);
			}
		}
		
		
	})
})